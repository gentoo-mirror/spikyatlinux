#!/usr/bin/env sh
# Add your custom hook code here
# Note that the working directory of the script will be the location
# from which s-tui was launched.
